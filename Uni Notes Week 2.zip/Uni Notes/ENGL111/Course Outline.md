---
tags: outline
---
COURSE TITLE: English Composition  
COURSE NUMBER: ENGL 111  
PREREQUISITES: Demonstrated competency through appropriate assessment or earning a grade of  
“C” or better in: ENGL 093 Introduction to College Writing and ENGL 083 Reading Strategies for  
College or ENGL 095 Integrated Reading and Writing or FOUN 071 Tech Foundations II  
COREQUISITES: Demonstrated competency through appropriate assessment or earning a grade of “C”  
or better in: ENGL 063 Co-Requisite Reading Strategies for College or ENGL 073 Co-Requisite  
Introduction to College Writing or ENGL 075 Co-Requisite Integrated Reading and Writing  
SCHOOL: Arts, Sciences & Education  
PROGRAM: Liberal Arts  
CREDIT HOURS: 3  
CONTACT HOURS: Lecture: 3  
DATE OF LAST REVISION: Summer 2019  
EFFECTIVE DATE OF THIS REVISION: Spring 2020
CATALOG DESCRIPTION: English Composition is designed to develop students’ abilities to craft,  
organize, and express ideas clearly and effectively in their own writing. This course incorporates critical  
reading, critical thinking, and the writing process, as well as research and the ethical use of sources in  
writing for the academic community. Extended essays, including a researched argument, are required.

MAJOR COURSE LEARNING OBJECTIVES: Upon successful completion of this course, students  
will be expected to:

1. Compose texts that exhibit appropriate rhetorical choices, including attention to audience,  
    purpose, context, genre, culture, and convention.
2. Develop and apply strategies for critical reading, critical thinking, and information literacy.
3. Demonstrate a proficiency in locating, evaluating, and analyzing academically appropriate  
    research material.
4. Analyze and synthesize researched information to develop and support original claims.
5. Develop and advance thesis-driven compositions in an organized progression with appropriate  
    supporting information.
6. Engage in writing as a process through invention, multiple drafts, collaboration, reflection,  
    revision, and editing.
7. Employ correct techniques of style, formatting, and documentation when incorporating quotes,  
    paraphrases, and summaries from sources into compositions.
8. Produce texts that demonstrate control over style and writing conventions, including sentence  
    variety and complexity, word choice, tone, punctuation, grammar, usage, and spelling.

COURSE CONTENT: Topical areas of study will include –

- Academic writing                                             
- Navigating digital information
- The rhetorical situation                               
- Library and other research methods
- The writing process                                         
- Annotation
- Generating ideas                                             
- Citation and plagiarism
- Thesis statement development               
- Paraphrasing, summarizing, and quoting
- Essay organization                                           
- Documentation
- Analysis and synthesis                                   
- MLA and/or APA Style
- Argumentation                                                   
- Conventions of Standard Written English