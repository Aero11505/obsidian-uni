---
tags: theme
---
# What makes up Happy?
- New psychological science of happiness
- Investigate the relationships between: 
	- [[money and happiness]] 
	- [[nature and happiness]] 
	- [[social media and happiness]] 
	- [[happiness and relationships with others]]