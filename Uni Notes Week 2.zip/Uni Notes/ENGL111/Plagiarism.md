---
tags: ""
---
#whatisplagiarism 
Plagiarism is when you:
- Present ideas, images or testimony of others without citing the source of the material and/or implying in any way that such material is your own
- Paraphrase or summarize WITHOUT crediting the source of the material
- Directly quote with no quotation marks, footnotes, or textual citation of the source
- Submit material from one class or course as if it were originally produced for this class or course--even if it is your own material (in other words, reusing papers submitted for a previous class, even a previous section of ENGL 111, is considered autoplagiarism and is prohibited)
- Submit material written by someone else as your own; this includes purchasing a term paper or essay
- Submit a paper or assignment for which you have received so much help that the writing is different from your own
- Copy assignments in part or in whole previously submitted or written by another student