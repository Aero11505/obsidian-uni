---
tags: instructionalmethod
---
### Eight-week blended Learn Anywhere
**If you have fallen behind, don't succumb to the cycle of shame and avoidance. Keep showing up for class and participating as best you can.**  Asking for help is an act of courage, not a sign of weakness! I'm here to help, and if you are struggling in the class in any way, I will meet with you so we can create a recovery plan to help you get back on track.

###### Each class includes in-class graded assignments due by the end of the period. **You need to be here for all of class and complete these in-class assignments to get credit for them.**