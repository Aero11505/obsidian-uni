---
tags: main, guide, engl111
---
[[ENGL Homework due by Aug 27]]
### Genevieve Oliver, Instructor
- Attend in person in **Room B209 or on Zoom**
- Contact by email mainly  goliver@ivytech.edu
- Text or call at Google Voice #: 812-287-9384
- Weekly Zoom Student Hours on Mondays @ 9-10am & Thursdays @ 2-3pm for me to ask questions & get help.
---
###### [[Closed Research theme]]
###### [[Course Outline]]
[[Instructional Method]]
[[Late-work Policy]]
[[Plagiarism]]
[[Types of Assignments]]
