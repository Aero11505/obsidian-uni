---
tags: infm109, main
---
*COPY DAY 1 NOTES FROM GDOC HERE*
[[Types of Information Systems]]
[[Value Chain]]
[[Supply Chain]]
![[img6 1.png]]

[[Strategic Planning]]
[[Information System Strategic Planning]]
[[Information Systems Careers]]
[[Typical Information System Roles]]
[[Shadow IT]]
[[Continuous Education]]
###### M1 PowerPoint Summary
* Managers must use [[IS]](information systems) to gain competitive advantage
* [[Leavitt's Diamond]] helps to successfully introduce new systems into the workplace
* [[Strategic Planning]] helps identify desired outcomes and formulate feasible plans to achieve objectives
* Various [[IS]] workers need a variety of skills and certifications



