###### Strategic Planning
* Managerial process designed to identify initiatives and projects to achieve organizational objectives
* Must recognize that the organization and everything around it is in a state of flux
###### Benefits
* Provides a [[framework]] and clearly defined direction to guide decision making
* Provides effective use of organization's resources
* Allows organization to be proactive
* Improves communication
###### Considerations
* Long-term impact of each strategy on [[revenue]] and [[profit]]
* Degree of risk involved
* Amount and types of resource required
* Potential competitive reaction
##### MUST BE CONSISTENT WITH ORGANIZATIONAL PLAN
