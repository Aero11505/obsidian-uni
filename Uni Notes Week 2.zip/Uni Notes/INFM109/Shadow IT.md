###### [[Shadow IT]]
* [[IS]] and solutions built and deployed by departments outside of the [[IS]] department
* Enables business managers to quickly create highly innovative solutions to real business problems and to test out these solutions
* May deploy non-approved vendors, software, or hardware and may not meet the [[IS]] department standards
![[Pasted image 20230824102727.png]]
![[Pasted image 20230824102742.png]]
