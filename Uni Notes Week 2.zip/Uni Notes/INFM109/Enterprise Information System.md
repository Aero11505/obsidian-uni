---
tags: informationsystems
---
Facilitates organization-wide business needs