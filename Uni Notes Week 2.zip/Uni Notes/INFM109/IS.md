---
IS: ""
tags: informationsystems
---
###### [[Types of Information Systems]]
