###### Identify resources to invest in
* Support corporate and business [[unit strategies]]
* Includes technologies, vendors, competencies, people, systems, and projects
###### [[IS]] plan influences:
* New technology innovations
* Innovative thinkers
* Perception of [[IS]] organization
	* Cost center/service provider
	* Business partner/business peer
	* Game changer
![[img7.png]]
![[Pasted image 20230824101208.png]]
![[Pasted image 20230824101125.png]] 
