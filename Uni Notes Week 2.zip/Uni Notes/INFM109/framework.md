---
tags: framework, whatisaframework
---
Your organization's strategic framework is a document that contains your vision, mission, values, plans, objectives, and tactics. It may contain a lot of information but can be written in a relatively concise fashion. Your strategic framework contains your complete vision for the direction of your organization.