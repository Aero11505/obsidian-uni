* 
https://benjaminwann.com/blog/keep-or-drop-analysis-in-manufacturing-explained-a-beginners-guide

* If a large corpo did not have its suppliers acting as "product managers" as is the case with Walmart, how do you think the company might best go about making business decisions about which products to carry or drop, which stores to carry the products in, and in what quantities?

* Do you think the time of year or holidaays affect inventory decisions, and if yes, how so?

* How might the geographic location of the store affect the products it carries?
