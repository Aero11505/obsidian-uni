---
tags: informationsystems
---
Improves [[productivity]] of individual users in performing stand-alone tasks
