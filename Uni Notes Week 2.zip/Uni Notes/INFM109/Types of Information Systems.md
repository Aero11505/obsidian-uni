---
IS: ""
tags: informationsystems
---
[[Personal Information System]]
[[Workgroup Information System]]
[[Enterprise Information System]]
[[Interorganizational IS]]