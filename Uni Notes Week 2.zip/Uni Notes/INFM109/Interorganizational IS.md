---
tags: informationsystems
---
Enables the sharing of information across organizational boundaries