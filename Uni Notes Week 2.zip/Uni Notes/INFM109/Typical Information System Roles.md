###### Chief information officer
* Employs [[IS]] department's equipment and personnel
* Achieves organization's goals
* Understands [[finance]], [[accounting]], [[return on investment]]
###### Software developer
* Creative mind behind computer programs
* Develops applications and operating systems
* Tests, debugs, and upgrades software
###### Information systems security analyst
* Plans, designs, implements, and maintains integrity of systems and data
* Analyzes security measures to identify and implement improvements
* Develops and delivers security measures training
* Creates security breach action plans
* May work for computer companies, consulting firms, or business and financial companies
###### Systems analyst
* Consults with management and users
* Defines scope of and requirements for new information systems
* Brings business and information systems together
###### Programmer
* Converts program design into a working program
	* Written in one of many computer languages
###### Web developer
* Designs and maintains Web sites
* May monitor Web site performance/capacity
###### Business analyst
* Improves company competitiveness and performance
* Evaluates and solves business challenges
* Must possess a broad set of business knowledge and skills
![[Pasted image 20230824102143.png]]
###### Other [[IS]] Careers
* Consultants at large firms
* Technology company employees
	* Work on cutting edge technology
* Small business entrepreneurs starting their own [[IS]] business
* [[IS]] entrepreneurs or freelancers
	* Write programs, work on [[IS]] projects with larger businesses, or write phone apps