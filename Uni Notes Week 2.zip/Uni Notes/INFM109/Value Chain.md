* Series of activities to transform inputs to outputs
* Value of the input should increase