###### [[IS]] worker required skills
* [[Data analysis]]
* Mobile device application design/build skills
* Traditional programming & application development
* Technical support expertise
* Project management
* Networking & cloud computing
* System audit & security
* Web design & development
* Data center operations knowledge
###### [[IS]] professionals in high demand
###### U.S. Bureau of Labor Statistics (BLS) data
* 4.6 million people employed in computer-related occupations (2016)
* Forecast 591,000 new computing job openings between 2016-2026
![[Pasted image 20230824101643.png]]
