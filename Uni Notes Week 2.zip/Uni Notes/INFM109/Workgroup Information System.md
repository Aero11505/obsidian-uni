---
tags: informationsystems
---
Enables people to work together effectively