###### Certification
* A process for testing skills & knowledge
* Results in a statement by the certifying authority that confirms an individual is capable of performing particular tasks
* Frequently involves specific, vendor-provided or vendor-endorsed coursework
![[Pasted image 20230824103256.png]]
![[Pasted image 20230824105540.png]]
![[Pasted image 20230824105549.png]]
