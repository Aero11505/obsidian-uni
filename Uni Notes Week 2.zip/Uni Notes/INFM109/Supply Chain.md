* Key [[Value Chain]]
* Primary processes include [[inbound logistics]], [[operations]], [[outbound logistics]], [[marketing]] and [[sales]], and [[service]]
* Concerned with the creation and/or delivery of a product or service
* ![[img6 1.png]]
