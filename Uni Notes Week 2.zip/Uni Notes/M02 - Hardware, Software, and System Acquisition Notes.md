###### Objectives
* Describe the functions of the four [[fundamental hardware components]] of every computer
* Explain the difference between [[multiprocessing]], [[parallel processing]], and [[grid computing]]
* Describe how each of the three [[primary classes of computers]] is used within an organization
* Identify the three or four subclasses associated with each primary class of computer.
* Identify three primary features that distinguish tier 1, 2, 3, and 4 data centers
* State the three primary goals of the [["green computing"]] program
* List the two basic kinds of software and their associated subclasses
* Describe the role of the [[operating system]]
* State three [[cost saving benefits]] associated with server virtualization
* Describe how the [[service-oriented architecture approach]] is used to build software and microservices
* Identify three advantages of off-the-shelf versus proprietary software
* State four key advantages of the software as a service model
* Give an example of how [[application software]] is used in the personal, workgroup, and enterprise sphere of influence
* Identify five tasks for which programming languages are commonly used
* Identify the three primary types of [[end-user license agreements]]
* Compare open-source software to licensed software in terms of how each is used and supported
###### Why Learn About Hardware and Software?
* State-of-the-art hardware and software
	* Enables enhanced network and data security
	* Increases productivity
	* Improves employee morale
	* Lower costs
	* Enables organization competitiveness
* Managerial expectation regarding hardware and software investments
	* Define business needs
	* Ask relevant questions and evaluate options

###### Anatomy of a Computer
![[Pasted image 20230829100046.png]]
* Phases for completing an instruction
	* Instruction phase
		* Fetch instruction
		* Decode instruction
	* Execution phase
		* Execute instruction
		* Store results
![[Pasted image 20230829100203.png]]
###### Processor
* **Multicore processor**
	* Two or more independent processing units
	* Cores sequence and execute instructions
	* Processor generates heat
* **Clock speed**
	* Series of electronic pulses
	* Produced at a predetermined rate
	* Governs speed at which steps are completed
* **Gigahertz (GHz)** measures clock speed
	* One billion cycles per second (per Gigahert)
* Manufacturing processors
	* **Integrated circuit (IC)** or chip
		* Set of electronic circuits on one small piece of semiconductor material (normally silicon)
		* Can be extremely small
	* **Semiconductor fabrication plant** 
		* Called a fab or foundry
		* Factory where integrated circuits are manufactured
		* Use extreme ultraviolet lithography (EUVL) process
		* Extremely expensive to set up
* **Multiprocessing**
	* Simultaneously execute two or more instructions
	* **Coprocessors**
		* One processor executes specific instruction types while CPU works on another processing activity
* **Parallel processing**
	* Simultaneously execute the same task on multiple processors
	* **Massively parallel processing systems**
		* Link hundreds or thousands of processors
	* **Grid computing**
		* Coordinated computers
		* Owned by multiple individuals or organizations
		* Solves a common problem
		* Low-cost approach to parallel processing
		* Central server is key
			* Divides computing task into subtasks
			* Assigns work to grid computers
			* Monitors processing

###### Main memory
* **Main memory**
	* Rapidly provides working storage to the CPU
		* Used for program instructions and data
	* Data storage in memory
		* Eight bits together form a **byte (B)**
		* Storage capacity measures in bytes
		* One byte equals one character of data
	* ![[Pasted image 20230829102252.png]]
###### RAM and Cache
* **Random access memory (RAM)**
	* Memory where instructions or data can be temporarily stored
	* Volatile storage
	* Mounted directly on main circuit board
	* Many varieties
		* Static random access memory (SRAM)
		* Dynamic random access memory (DRAM)
		* Double data rate synchronous dynamic random access memory (DDR SDRAM)
* **Cache memory**
	* High-speed memory
	* Processor can access more rapidly than main memory
* **Read-only memory** (ROM)
	* Nonvolatile memory providing permanent storage for data and instructions that do not change
* ROM varieties
	* Programmable read-only memory (PROM)
		* Holds data and instructions that can never be changed
	* Electrically erasable programmable read-only memory (EEPROM)
		* User-modifiable read-only memory
		* Can be erased and reprogrammed repeatedly through the application of higher-than-normal electrical voltage

###### Secondary Storage
* **Secondary storage**
	* Stores large amounts of data, instructions, and information
	* More permanent than main memory
	* Less expensive than primary memory
	* Not directly accessible by the CPU
* Secondary storage devices
	* Magnetic tape
	* Hard disk drive (HDD)
	* Redundant array of independent/inexpensive disks (RAID)
	* Virtual tape
* Solid state secondary storage devices
	* **Solid state storage device (SSD)**
		* Stores data in memory chips
		* Uses less power and provides faster data access
		* No moving parts
* ![[Pasted image 20230829110847.png]]
###### Input/Output Devices

* Allows interaction with a computer system
* Common person computer input devices
	* Keyboard and a computer mouse
* Optical data readers
	* Special scanning device to scan documents
		* Optical mark recognition (OMR)
		* Optical character recognition (OCR)
* Bar-code scanners
	* Laser scanner reads a bar-coded label
	* May be stationary or handheld
* ![[Pasted image 20230829113151.png]]
* **Radio frequency identification devices (RFID)**
	* Microchip with an antenna broadcasts its unique identifier and location to receivers
		* Transmits data to a tag
		* Tag read by an RFID reader and processed
* Pen input devices
	* Pen touches screen and activates commands
* Touch screens
	* Activate programs or trigger other types of actions
* ![[Pasted image 20230829113416.png]]
###### Output Devices
* Display screens
	* **Computer graphics card**
		* Translates binary data from CPU into an image
	* **Graphics processing unit (GPU)**
		* Processing chip that renders images on the screen
* Printers and plotters
	* Laser printers and inkjet printers
	* Plotters used for general design work
* 3D printers
	* Create objects using strands of a plastic filament or synthetic powder
* ![[Pasted image 20230829113613.png]]
###### Computer System Classes
* Computer classifications
	* Special-purpose used for limited applications
	* General-purpose used for a variety of applications
	* Three classes of general-purpose computers
		* Portable computers used by one user at a time
		* Nonportable computers used by one person at a time
		* Systems used by multiple concurrent users

###### Portable Computers
* **Portable computers**
	* Small enough to carry easily
* Four categories
	* Smartphones
	* Laptops
	* Notebooks
	* Tablets
* ![[Pasted image 20230829113831.png]]
###### Nonportable, Single-User Computers
* **Thin clients**
	* Low-cost, centrally managed computers
	* No internal or external attached drives for data storage
* **Desktop computers**
	* Single-user computer systems
	* Highly versatile
	* Provide sufficient computing power, memory, and storage for most business computing tasks
* **Nettop computer**
	* Very small, inexpensive desktop computer
	* Used for Internet access, email, accessing Web-based applications, document processing, and audio/video playback
	* Require one-tenth the amount of power
* **Workstations**
	* More powerful than personal computers
	* Small enough to fit on a desktop
	* Support engineering and technical users
###### Servers, Mainframes, and Supercomputers
* **Server**
	* Computer employed by many users to perform a specific task
	* Several types
		* Web server, enterprise server, file server
	* Offers great **scalability**
		* The ability to increase the processing capacity of a computer system so that it can handle more users, more data, or more transactions in a given period
* **Mainframe computer**
	* Large, powerful computer
	* Shared by dozens or hundreds of concurrent users connected to the machine over a network
	* **Backward compatibility**
		* Key feature allowing current mainframes to run software created decades ago
* **Supercomputers**
	* Special-purpose machines
		* Designed for applications requiring extensive and rapid computational capabilities
* ![[Pasted image 20230829114927.png]]
###### Quantum Computers
